<?php
$hn = 'localhost';
$db = 'WebProject';
$un = 'zth';
$pw = 'webfinal2020';
?>